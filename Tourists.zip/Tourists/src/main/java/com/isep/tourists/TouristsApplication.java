package com.isep.tourists;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TouristsApplication {

    public static void main(String[] args) {
        SpringApplication.run(TouristsApplication.class, args);
    }

}
